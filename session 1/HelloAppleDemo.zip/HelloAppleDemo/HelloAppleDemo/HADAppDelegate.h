//
//  HADAppDelegate.h
//  HelloAppleDemo
//
//  Created by Vu Tran Lam on 1/25/14.
//  Copyright (c) 2014 FPT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HADAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
