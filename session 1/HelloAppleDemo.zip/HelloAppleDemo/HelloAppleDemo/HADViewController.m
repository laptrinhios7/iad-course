//
//  HADViewController.m
//  HelloAppleDemo
//
//  Created by Vu Tran Lam on 1/25/14.
//  Copyright (c) 2014 FPT. All rights reserved.
//

#import "HADViewController.h"

@interface HADViewController ()

@end

@implementation HADViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
