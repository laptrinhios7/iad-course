//
//  HADViewController.h
//  HelloAppleDemo
//
//  Created by Vu Tran Lam on 1/25/14.
//  Copyright (c) 2014 FPT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HADViewController : UIViewController

@end
