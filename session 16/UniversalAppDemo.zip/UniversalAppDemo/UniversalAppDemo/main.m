//
//  main.m
//  UniversalAppDemo
//
//  Created by Vu Tran Lam on 12/17/13.
//  Copyright (c) 2013 FPT. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UADAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([UADAppDelegate class]));
    }
}
