//
//  UADAppDelegate.h
//  UniversalAppDemo
//
//  Created by Vu Tran Lam on 12/17/13.
//  Copyright (c) 2013 FPT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UADAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
