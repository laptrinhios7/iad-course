//
//  AppDelegate.h
//  Ratings
//
//  Created by Marin Todorov on 8/9/13.
//
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
