//
//  Player.m
//  Ratings
//
//  Created by Marin Todorov on 8/9/13.
//
//

#import "Player.h"

@implementation Player

@end
