//
//  ViewController.h
//  Ratings
//
//  Created by Marin Todorov on 8/9/13.
//
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@end
