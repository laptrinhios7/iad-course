//
//  Person.m
//  CarDemo
//
//  Created by Vu Tran Lam on 3/14/14.
//  Copyright (c) 2014 FPT. All rights reserved.
//

// Person.m

#import "Person.h"

@implementation Person

- (NSString *)description
{
    return self.name;
}

@end
